title: Kingdoms
tags: 

### Kingdoms
* [Galinor](/kingdoms/galinor)
* [Termina](/kingdoms/termina)
* [Duros](/kingdoms/duros)