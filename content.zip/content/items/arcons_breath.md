title: Arcon's Breath Artifacts
tags: 

Arcon the Titan fell down. Mad at the gods, put his anger 
Controls storms.
High Acolate of Arcona, stolen by pirates
Comprised of 3 parts.

The Fury (Horn)
Calls a storm

The Dominion (Crown)
Controls the storm

The Judgement (Astrolabe)
Targeted location of the storm

### Parts
* [The Fury (Horn)](/items/the_fury)
* [The Dominion (Crown)](/items/the_dominion)
* [The Judgement (Astrolabe)](/items/the_judgement)

*Can use each of them to find the others

Storms can rip holes into other planes
Storms get more powerful the more often it is used.

*Controls the arcane energy flowing between the planes. 
Cannot destroy the artifacts without allowing arcane energy to flow between the planes unrestrained.

