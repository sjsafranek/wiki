# encoding: utf-8
SECRET_KEY='a unique and long key'
TITLE='D&D Wiki' # Title Optional
