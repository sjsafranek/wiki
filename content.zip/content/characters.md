title: Characters
tags: 

### PCs
* [Ral Zarek](/characters/ral_zarek)
* [Niv Izzet](/characters/niv_izzet)
* [Milo](/characters/milo)
* [Aust](/characters/aust)
* [Ovin](/characters/ovin)
* [Ashiok Rakdos](/characters/ashiok_rakdos)
* [Gwenavive](/characters/gwenavive)
* [Vyr](/characters/vyr)
* [Siliki](/characters/siliki)
* [Sorsha](/characters/sorsha)

### NPCs
* [Fahalis Reshen](/characters/fahalis_reshen)
* [Milius Moores](/characters/milius_moores)
* [Emrakul (Titan of Corruption)](/characters/emrakul)
* [Lord Victor](/characters/lord_victor)
* [Raster](/characters/raster)
* [Gethon Haralt](/characters/gethon_haralt)
* [Sir Thomas](/characters/sir_thomas)
* [Zeek](/characters/zeek)
* [Sir Kedrick](/characters/sir_kedrick)
* [Archmage Brenard](/characters/archmage_brenard)
* [Zukai](/characters/zukai)
* [Grim Spector](/characters/grim_spector)
* [Malistar](/characters/malistar)
* [Jigen](/characters/jigen)
* [Nix](/characters/nix)
* [Arcon (The Titan)](/characters/arcon)
