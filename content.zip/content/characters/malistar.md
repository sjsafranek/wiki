title: Malistar
tags: 

Leader of the Brotherhood. Wears a white mask. In search of Arcons Breath. 
Able to give people the ability to harness arcane magic.
Brotherhoods brains are linked (green eyes)
Might not have the other pieces
Terrorizing the country sides looking for the artifact