title: Nix
tags: npc

When on the "chaos" plane, Nix (Halfling), showed Ral his parents and that Emrakul was manipulating him. His existence is not confirmed and is considered that of legend. Books within the Magis tower refered to Nix as a messenger of the Gods.