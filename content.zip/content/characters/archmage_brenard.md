title: Archmage Brenard
tags: Termina, npc

Archmage of the Magis Tower in Merbia, Termina