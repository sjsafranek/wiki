title: Sorsha
tags: 

Wingrider. Helped The Group defeat the Brotherhood in Merbia. Silverfeathers (Gryphon).