title: Zukai
tags: npc


Incubus who stole the life force of Archmage Brenards older daughter. (Succubus)
