title: Sir Kedrick
tags: sky sentinels, termina

Leader of the Sky Sentinels. "Friend" of Sir Thomas