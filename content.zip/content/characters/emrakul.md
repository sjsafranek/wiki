title: Emrakul
tags: npc

Feeds on planes. Does not affect unliving matter. Twists all living things. Leaves behind yellow dust. Lives outside the planes. When it wants to feed it extends part of its "body" into the plane to create a physical manifestation, along with an army of drones. Refers to herself as The Promised End. Thousands of years ago “she” was banished by the Gods from the planes and is assumed to have been destroyed for good. Wishes to use Arcons Breath to free her from her imprisonment.
