title: Zeek
tags: npc

Old soldier who hired The Group. Turned out to be risen from the dead and touched by the Grim Spector. Zeek had previously been in Lord Victor Gimant company and killed inoccent people. After this he consumed a vial of poison and died. After a couple days Lord Victor brought him back to life and promised to send him to the Sky God if he retrieved the artifact (Arcons's Breath).
500 Brave