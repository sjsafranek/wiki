title: Sir Thomas
tags: npc, dawn legion, galinor

Leader of the Dawn Legion