title: Grim Spector
tags: npc


“Grim Reaper”. Appears in areas w/ a lot of death. Take dead from the realm of the living to the realm of the dead. 