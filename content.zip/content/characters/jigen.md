title: Jigen
tags: 

Grand Master of the Rivers Bend Monastery. The Group gave the horn for safe keeping. Strive to keep power neutral throughout the realm.
Milo and Aust are from the Rivers Bend Monastery.
