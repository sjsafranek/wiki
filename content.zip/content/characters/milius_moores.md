title: Milius Moores
tags: npc, emrakul

10 years ago a student of the Magis Tower. Rented same books as step father regarding closing connections to other planes. He took the books and left....