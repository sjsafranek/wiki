title: Fahalis Reshen
tags: npc

Captain of the Saucy Mare
Fought banish Emrakul
Asimar

Ancient Aasimar who once helped to banish Emrakul from the planes. He now sails around the world on his ship, The Saucy Mare (w/ a crew of grown robots), delivering supplies to the needy. 
573 years old.
Helped banish Emrukal.