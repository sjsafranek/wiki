title: Lord Victor
tags: galenor

Very old war hero of Galenor. Uses blood transfers to keep himself young. Extremely powerful and un impacted by magic. Seeks to use The Horn to irradicate all non human life from the realm.
Should be 80 years old
Iron Fist of the Empire. Previous commander of the 500 Brave.
National Hero
Leech marks on arm for blood transfusion. Extending life unnaturally.