title: Galinor
tags: galinor, kingdom

Galinor

Capital: Vale
Ruler: King
Spell Caster Title: Wizards
Elite Fighting Unit: The 500 Brave
Primary Cultural Identity: Success

Galinor is the largest and most prolific kingdom in the realm. Seated on the western coast, in the fertile mid region of the continent, The Norin people have always found agricultural success. This has given the nation and it's people abundant resources for trade and comfort. Life in Galinor is comparatively easy, survival a meager struggle and the people have learned a life of privilege. They are also quick to forget that the people's of other lands do not share their same privilege and can readily take a disparaging outlook on those less fortunate. Bearing traditional, god fearing views, Galinor is a human-centric nation viewing other sapient races as begin second class citizens. It is also worth noting, churches and other temples of worship are bastions of hypocrisy in Galinor and fonts of much corruption.

Because of their fertile agriculture and ideal setting, Galinor quickly rose to prominence among the other major kingdoms and is currently the reigning super-power of the realm. They outfit the largest standing army and control the most preferable trade routes. The mighty economy of Galinor has been it's most decisive weapon in any conflict, often outspending competitors or maneuvering them into such disadvantageous trading positions that capitulation is all but assured. Knighthoods and Lordships in Galinor are almost dismissed as titles of vanity, rather than badges of service and the armies are largely unaccustomed to the hardships of prolonged conflict.

Being such a large nation, Galinor is also the most bureaucratic and litigious of all the major kingdoms. A vastly intricate system of laws were established centuries ago and to this day those very laws continue to protect the interests of the wealthy by exploiting the working class. The royal council is comprised of ministers appointed by the king. These ministers claim fealty to the realm but owe their allegiance to their own agendas.

The capital, Vale, is a vast, sprawling metropolis. It is considered the cultural and economic hub of the entire realm, though that claim is universally disputed. White collar crime runs rampant through the kingdom and wealthy lords raise mercenary armies to enforce their will. It is a land where the wealthy can fashion their own crowns and claim their own domains until the next wealthiest is able to see them toppled.

Throughout its long history, Galinor has had conflict with nearly every other major power in the realm. The nation frequently seeks to expand its gargantuan tracts and occasionally swells to an unsustainable size. They have found their chief rival in Termina, the secessionist power that fled their borders long ago and the two have long been at war. In modern times, tensions between the two nations have cooled to a grudging, if tenuous peace. The Elvish kingdom of Tir-Azell, ever dismissive and disdainful of human kingdoms, hold Galinor in the highest esteem. If not out of respect for the nation's people (of which they have none) out of respect for its wealth.

Two and a half centuries ago, when Dhuros caught to cloak the world in darkness and conquer the realm, Galinor was the first nation to raise arms in opposition. The conflict was long and furious, costing both nations countless lives and resources. Though the war was decided after the involvement of Vallenheim and Termina, the Norin people have immortalized themselves in song and history as being solely responsible for victory. This flexible interpretation of history and dedication to self-aggrandizing has earned the kingdom a less than forgiving reputation among the realm.


### Places
* [Arteva](/kingdoms/galinor/arteva)

### Groups
* [Dawn Legion](/kingdoms/galinor/dawn_legion)
* [500 Brave](/kingdoms/galinor/500_brave)
