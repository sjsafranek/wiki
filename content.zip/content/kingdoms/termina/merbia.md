title: Merbia
tags: 

The Group sailed to Merbia from the Termisian coast via a river boat. When they got to Merbia they saw that it was under attack by Brotherhood forces. They assisted in defending the city and fending off the Brotherhood forces from the surrounding refugee camp. Once inside they went to the Magis tower to speak with Archmage Brenard on how to destroy Arcons Breath. They discovered that Brenards two daughters had disappeared two days earlier and that the Archmage had closed himself off. During their investigation they found that a mysterious man (from the free-lands) named Zukai had come into the city and befriended Brenard about a month prior. Zukai seemed to be running the Magis tower in Brenards apparent absence. Gwenavive and Aust tracked down a mage named Jasper who pointed them in the direction of where the daughters could possibly be. 

They tracked down and found both daughters in a temple a few miles outside of the city. Ral read the youngest daughters thoughts and discovered that Zukai had brought them there. The continued searching the temple and discovered the oldest daughter chained to the wall with magic orbs suspended  above. Her life-force had been leeched and she now resembled a 90 year old woman. While they were unchaining her a winged demonic creature flew down from an opening above and took the orbs.

The Group lead the daughters back to the Magis tower in Merbia and were showered with praise. They explained to Brenard what had happened. The next day they found Zukai in Brenards chambers and Ral began hurling spells. Zukai revealed himself to be a Succubus and managed to escape.

Archmage informed The Group about Arcon's Breath
Brotherhood attacked city and set up a shield around the Magis Tower
Sorsha
