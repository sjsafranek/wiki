title: Duros
tags: 

It was near the Durosean coast that Ral received a vision from Emrakul that would help find the object to speed her entry to the material plane. The vision was a glimpse of the grim specter. This lead Vyr and Ral to come into contact with the The Group. Ral read the thoughts of Zeek. He saw the Grim Specter touching hands with Zeek, and caught a glimpse of The Horn (Arcons Breath), with the The Group had just acquired. From there Ral and Vyr joined The Group in hopes of stealing Arcons Breath to give to Emrakul.

Ashiok Rakdos
grew up and served in the Durosian army