title: Arteva, Galenor
tags: 

Shortly after retrieving the artifact from the cave, The Group found themselves in Arteva, a coastal port ctiy of Galenor. Vyr and Ral tried to convince Ovin to give them the horn. This drove Ovin to take the horn and leave the inn where they were all staying. On the street Ovin was accosted by a group of thieves. Ovin awoke a few hours later and found himself in a city cell with an extremely intoxicated Zeek. While searching through Ovin's backpack, a guard found the horn and blew it.

A powerful storm erupted and swept through the city. The city quickly became flooded and lightning elementals started raining through town destroying buildings. The Group barely managed to survive and escape to a building at the center of town were a powerful mage had setup a shield from the elementals. The storm subsided by the morning leaving the city in ruins.

The Brotherhood attacked the city the next morning. During the confusion The Group managed to board a small boat and was taken aboard the Saucy Mare, captained by Val Halis Reshen.
